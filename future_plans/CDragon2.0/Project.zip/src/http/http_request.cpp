#include "simdjson.h"
#include "http_request.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>

using std::string, std::istringstream, std::ostringstream, std::getline, std::cerr, std::endl;

HttpRequest::HttpRequest(const string& rawRequest) {
    parse(rawRequest);
}

void HttpRequest::parse(const string& rawRequest) {
    istringstream stream(rawRequest);
    string line;

    // Парсинг первой строки запроса (метод, путь и query параметры)
    getline(stream, line);
    parseMethodAndPathAndQueryParams(line);

    // Парсинг заголовков
    parseHeaders(stream);

    // Извлекаем тело запроса
    string body;
    if (stream.peek() != EOF) {
        ostringstream bodyStream;
        bodyStream << stream.rdbuf();
        body = bodyStream.str();
    }

    // Если Content-Type: application/json, парсим тело как JSON
    if (headers.find("Content-Type") != headers.end() && headers["Content-Type"] == "application/json") {
        parseJsonData(body);
    }
}

void HttpRequest::parseMethodAndPathAndQueryParams(const string& line) {
    istringstream requestLine(line);
    requestLine >> method >> path;

    // Парсинг параметров query
    auto pos = path.find('?');
    if (pos != string::npos) {
        string queryString = path.substr(pos + 1);
        path = path.substr(0, pos);

        parseQueryParams(queryString);
    }
}

void HttpRequest::parseQueryParams(const string& queryString) {
    istringstream queryStream(queryString);
    string param;
    
    while (getline(queryStream, param, '&')) {
        auto equalsPos = param.find('=');
        if (equalsPos != string::npos) {
            string key = param.substr(0, equalsPos);
            string value = param.substr(equalsPos + 1);

            queryParams.insert({key, value});
        }
    }
}

void HttpRequest::parseHeaders(istringstream& stream) {
    string line;
    while (getline(stream, line) && !line.empty()) {
        auto delimiterPos = line.find(':');
        if (delimiterPos != string::npos) {
            string headerKey = line.substr(0, delimiterPos);
            string headerValue = line.substr(delimiterPos + 2);  // Убираем ": "

            headers.insert({headerKey, headerValue});
        }
    }
}

void HttpRequest::parseJsonData(const string& body) {
    using namespace simdjson;
    try {
        dom::parser parser;
        dom::element json = parser.parse(body);

        // Перебираем ключи и значения JSON
        for (auto [key, value] : json.get_object()) {
            if (value.is_string()) {
                jsonData.insert({string(key), string(value.get_string().value())});
            }
        }
    } catch (const simdjson_error& e) {
        cerr << "Ошибка парсинга JSON: " << e.what() << endl;
    }
}

inline void HttpRequest::parsePathParams(const std::smatch& match) {
    // Парсим параметры запроса, если они есть
    for (size_t i = 0; i < match.size(); ++i) {
        pathParams.emplace_back(match[i].str());
    }
}
