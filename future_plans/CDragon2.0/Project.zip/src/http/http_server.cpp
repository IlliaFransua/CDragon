// ToDo:
// 1. Переделать HttpServer на нормальное

#include "http_server.h"
#include "http_request.h"
#include "http_response.h"
#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>


using std::cout, std::endl;

void HttpServer::start() {
    // Cсылка на открытый сокет
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Не вдалося підключити сокет");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in address;
    int reuse_address = 1;              // Резрешение повторного использования сокета
    int address_len = sizeof(address);
    
    // Установка параметров сокета
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &reuse_address, sizeof(reuse_address)) < 0) {
        perror("Не вдалося встановити параметри для setsockopt");
        exit(EXIT_FAILURE);
    }
    
    cout << "Сокет створено успішно" << endl;

    // Настройка адреса и порта
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;  // Привязка ко всем интерфейсам устройства
    address.sin_port = htons(8080);        // Порт 8080

    // Привязка сокета к указанному айпи адресу и порту
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Не вдалося зв'язати сокет з IP адресою");
        exit(EXIT_FAILURE);
    }

    cout << "Сокет прив'язано до адреси " << *(inet_ntoa(address.sin_addr)) << " до порту " << address.sin_port << endl;

    if (listen(server_fd, 100) < 0) {
        perror("Помилка під час переведення сокета в режим очікування підключень");
        exit(EXIT_FAILURE);
    }

    cout << "Сервер слухає на порту 8080..." << endl;

    while (true) {
        int new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&address_len);
        if (new_socket < 0) {
            perror("Не вдалося прийняти нове з'єднання від клієнта");
            continue;
        }

        char buffer[1024] = {0};
        int valread = read(new_socket, buffer, sizeof(buffer) - 1); // Место для '\0'
        if (valread < 0) {
            perror("Не вдалося прочитати дані з нового з'єднання");
            close(new_socket);
            continue;
        }
        buffer[valread] = '\0';

        HttpRequest request(buffer);

        HttpResponse response;
        handleRequest(request, response);
        
        // Отправка ответа
        string responseStr = response.getResponse();
        send(new_socket, responseStr.c_str(), responseStr.size(), 0);
        
        close(new_socket);
    }

    close(server_fd);
}
