#include "http_response.h"
#include <sstream>

using std::string, std::ostringstream;

string HttpResponse::getResponse() {
    // Можно всё доработать
    ostringstream response;
    response << "HTTP/1.1 " << status << " OK\r\n";
    response << "Content-Length: " << body.size() << "\r\n";
    for(auto header : headers) {
        response << header.first << ": " << header.second << "\r\n";
    }
    response << "\r\n";
    response << body;
    return response.str();
}

void HttpResponse::addHeader(const string& key, const string& value) {
    headers.insert({key, value});
}
