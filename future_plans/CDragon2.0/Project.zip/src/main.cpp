#include "framework.h"

int main() {
    Framework app;
    app.run();
    return 0;
}
