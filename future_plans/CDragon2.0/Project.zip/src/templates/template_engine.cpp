#include "template_engine.h"

using namespace std;

string TemplateEngine::render(const string& templateName, const map<string, string>& context) {
    // Это не ренедер, а прососто для теста
    string result = "Rendered template: " + templateName + "\n";

    for (const auto& [key, value] : context) {
        result += key + ": " + value + "\n";
    }

    return result;
}
