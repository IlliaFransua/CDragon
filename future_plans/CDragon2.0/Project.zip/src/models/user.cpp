#include "user.h"

using std::string, std::map;

User::User(int id, const string& name, const string& email)
    : id(id), name(name), email(email) {}

int User::getId() const {
    return id;
}

string User::getName() const {
    return name;
}

string User::getEmail() const {
    return email;
}

map<string, string> User::toMap() const {
    return {
        {"id", std::to_string(id)},
        {"name", name},
        {"email", email}
    };
}
