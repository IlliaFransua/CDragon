#include "router.h"
#include <iostream>
#include <regex>

using std::string, std::regex, std::regex_replace, std::smatch;

void Router::addStaticRoute(const string& path, const function<void(HttpRequest&, HttpResponse&)>& handler) {
    staticRoutes.insert({path, handler});
}

void Router::addDynamicRoute(const string& pathPattern, const function<void(HttpRequest&, HttpResponse&)>& handler) {
    // /company/<companyid>/user/<userid> -> /company/([^/]+)/user/([^/]+)
    string regexPattern = regex_replace(pathPattern, regex("<[^/]+>"), "([^/]+)");
    dynamicRoutes.emplace_back(regex(regexPattern), handler);
}

void Router::routeRequest(HttpRequest& request, HttpResponse& response) {
    string path = request.getPath();
    
    // 1. Проверяем статические маршруты
    auto it = staticRoutes.find(path);
    if (it != staticRoutes.end()) {
        it->second(request, response);
        return;
    }

    // 2. Проверяем динамические маршруты
    for (const auto& [regexPattern, handler] : dynamicRoutes) {
        smatch match;   // Соответсвие
        if (regex_match(path, match, regexPattern)) {
            request.parsePathParams(match);
            handler(request, response);
            return;
        }
    }

    // 3. Если маршрут не найден
    response.setStatus(404);
    response.addHeader("Content-Type", "text/html; charset=utf-8");
    response.setBody("404 - Страница не найдена");
}
