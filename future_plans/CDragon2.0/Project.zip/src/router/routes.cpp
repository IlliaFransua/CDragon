#include "routes.h"
#include "http_request.h"
#include "http_response.h"
#include "user.h"

using std::string;

void setupRoutes(Router& router) {
    router.addStaticRoute("/", [](HttpRequest& request, HttpResponse& response) {
        response.setStatus(200);
        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody("Главаня");
    });

    router.addStaticRoute("/about", [](HttpRequest& request, HttpResponse& response) {
        response.setStatus(200);
        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody("О нас");
    });

    router.addStaticRoute("/user", [](HttpRequest& request, HttpResponse& response) {
        string userInfo;
        if (request.getQueryParams().size() > 0) { // Обработка динамического путя
            userInfo = "User Info:\n";

            for (const auto& [key, value] : request.getQueryParams()) {
                userInfo += key + ": " + value + "\n";
            }
        } else {
            User user(1, "Катя Nizhnyk", "katia.nizhnyk@icloud.com");
            
            // Преобразование данных пользователя в строку для ответа
            auto userData = user.toMap();
            userInfo = "User Info:\n";
            for (const auto& [key, value] : userData) {
                userInfo += key + ": " + value + "\n";
            }
        }

        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody(userInfo);
    });

    router.addDynamicRoute("/company/<companyid>", [](HttpRequest& request, HttpResponse& response) {
        string companyid = request.getPathParams().at(0);
        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody("<h1>Company ID: " + companyid + "</h1>");
    });

    router.addDynamicRoute("/company/<companyid>/<adress>", [](HttpRequest& request, HttpResponse& response) {
        string companyid = request.getPathParams().at(0);
        string adress = request.getPathParams().at(1);
        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody("<h1>Company ID: " + companyid + ", adress: " + adress + "</h1>");
    });

    router.addDynamicRoute("/company/<companyid>/user/<userid>", [](HttpRequest& request, HttpResponse& response) {
        string companyid = request.getPathParams().at(0);
        string userid = request.getPathParams().at(1);
        response.addHeader("Content-Type", "text/html; charset=utf-8");
        response.setBody("<h1>Company ID: " + companyid + ", User ID: " + userid + "</h1>");
    });
}
