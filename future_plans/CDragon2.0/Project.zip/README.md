Для сборки проекта используйте CMake:

```bash
mkdir build
cd build
cmake ..
make
