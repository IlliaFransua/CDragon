#ifndef HTTP_RESPONSE_H
#define HTTP_RESPONSE_H

#include <string>
#include <unordered_map>

using std::string, std::unordered_map;

class HttpResponse {
public:
    // Сеттеры
    void setStatus(int status);
    void setBody(const string& body);

    // Геттеры
    string getResponse();  // Полный ответ

    // Методы с приветом
    void addHeader(const string& key, const string& value);

private:
    int status = 200;                       // Cтатус ответа
    unordered_map<string, string> headers;  // Заголовки запроса
    string body;                            // Тело ответа
};

//Сеттеры
inline void HttpResponse::setBody(const string& body) { this->body = body; }
inline void HttpResponse::setStatus(int status) { this->status = status; }

#endif // HTTP_RESPONSE_H
