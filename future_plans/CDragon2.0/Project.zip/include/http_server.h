// ToDo:
// 1. Переделать HttpServer на нормальное

#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

#include <http_request.h>
#include <http_response.h>

using std::function;

class HttpServer {
public:
    void start();  // Запуск сервера (летим в космос)
    function<void(HttpRequest&, HttpResponse&)> handleRequest;  // Лямбда для обработки запросов
};

#endif // HTTP_SERVER_H
