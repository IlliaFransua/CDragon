#ifndef USER_H
#define USER_H

#include <string>
#include <map>

using std::string, std::map;

class User {
public:
    User(int id, const string& name, const string& email);
    
    int getId() const;
    string getName() const;
    string getEmail() const;

    map<string, string> toMap() const; // Преобразование в карту (для JSON и т.д.)

private:
    int id;
    string name;
    string email;
};

#endif // USER_H
