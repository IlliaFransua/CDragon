#ifndef FRAMEWORK_H
#define FRAMEWORK_H

class Framework {
public:
    void run();
};

#endif // FRAMEWORK_H
