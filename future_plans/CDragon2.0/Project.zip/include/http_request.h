#ifndef HTTP_REQUEST_H
#define HTTP_REQUEST_H

#include <string>
#include <map>
#include <unordered_map>
#include <string_view>
#include <regex>

using std::string, std::vector, std::unordered_map, std::istringstream;

class HttpRequest {
public:
    HttpRequest(const string& rawRequest);

    // Геттеры
    const string& getMethod() const noexcept;
    const string& getPath() const noexcept;
    const vector<string>& getPathParams() const noexcept;
    const unordered_map<string, string>& getQueryParams() const noexcept;
    const unordered_map<string, string>& getHeaders() const noexcept;
    const unordered_map<string, string>& getJsonData() const noexcept;

    // Методы с приветом
    void parsePathParams(const std::smatch& path);

private:
    string method;                        // GET, POST итд
    string path;                          // Путь запроса
    unordered_map<string, string> queryParams;  // Query параметры (/path?param=value)
    unordered_map<string, string> headers;      // Заголовки запроса
    unordered_map<string, string> jsonData;     // JSON данные из тела запроса
    vector<string> pathParams;            // Параметры пути (/company/<companyid>/user/<userid>)

    void parse(const string& rawRequest);

    void parseMethodAndPathAndQueryParams(const string& line);  // Парсинг первой строки запроса (метод, путь, параметры пути и query параметры)
    void parseQueryParams(const string& queryString);  // Парсинг query параметры
    void parseHeaders(istringstream& stream);  // Парсинг заголовков запроса
    void parseJsonData(const string& body);  // Парсинг JSON данных из тела запроса
};

// Геттеры
inline const string& HttpRequest::getMethod() const noexcept { return method; }
inline const string& HttpRequest::getPath() const noexcept { return path; }
inline const unordered_map<string, string>& HttpRequest::getQueryParams() const noexcept { return queryParams; }
inline const unordered_map<string, string>& HttpRequest::getHeaders() const noexcept { return headers; }
inline const unordered_map<string, string>& HttpRequest::getJsonData() const noexcept { return jsonData; }
inline const vector<string>& HttpRequest::getPathParams() const noexcept { return pathParams; }

#endif // HTTP_REQUEST_H
