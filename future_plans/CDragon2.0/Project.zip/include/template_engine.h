#ifndef TEMPLATE_ENGINE_H
#define TEMPLATE_ENGINE_H

#include <string>
#include <map>

using namespace std;

class TemplateEngine {
public:
    string render(const string& templateName, const map<string, string>& context);  // Рендеринг шаблона
};

#endif // TEMPLATE_ENGINE_H
