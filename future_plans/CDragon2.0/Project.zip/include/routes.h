#ifndef ROUTES_H
#define ROUTES_H

#include "router.h"

void setupRoutes(Router& router);  // Функция для установки маршрутов

#endif // ROUTES_H
