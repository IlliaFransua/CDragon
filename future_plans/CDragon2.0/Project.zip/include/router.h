// Классы для маршрутизации запросов

#ifndef ROUTER_H
#define ROUTER_H

#include "http_request.h"
#include "http_response.h"
#include <unordered_map>
#include <regex>
#include <functional>
#include <string>
#include <vector>
#include <iostream>

using std::unordered_map, std::function, std::vector, std::pair, std::regex;

class Router {
public:
    void addStaticRoute(const string& path, const function<void(HttpRequest&, HttpResponse&)>& handler);
    void addDynamicRoute(const string& pathPattern, const function<void(HttpRequest&, HttpResponse&)>& handler);
    
    void routeRequest(HttpRequest& request, HttpResponse& response);  // Направить запрос к его обработчику

private:
    unordered_map<string, function<void(HttpRequest& request, HttpResponse& response)>> staticRoutes;   // Статические маршруты
    vector<pair<regex, function<void(HttpRequest& request, HttpResponse& response)>>> dynamicRoutes;    // Динамические маршруты
};

#endif // ROUTER_H
